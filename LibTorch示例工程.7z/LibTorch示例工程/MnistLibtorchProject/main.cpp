#include "MnistLibtorchProject.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MnistLibtorchProject w;
    w.show();
    return a.exec();
}
