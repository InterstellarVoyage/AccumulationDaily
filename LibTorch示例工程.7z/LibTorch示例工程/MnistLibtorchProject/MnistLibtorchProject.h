#pragma once

#include <iostream>  
#include <memory>
#include <QtWidgets/QMainWindow>
#include <opencv.hpp>
#include <opencv2/core/core.hpp>  
#include <opencv2/highgui/highgui_c.h>
#include <opencv2/highgui/highgui.hpp>
#include "ui_MnistLibtorchProject.h"

#pragma execution_character_set("utf-8")

using namespace std;

class MnistLibtorchProject : public QMainWindow
{
    Q_OBJECT

public:
    MnistLibtorchProject(QWidget *parent = Q_NULLPTR);
    QGraphicsScene* originalScene;
   cv:: Mat m_img;  // ͼ��

private slots:
    void InputImgPushButton_pressed();
    void InferImgNumber_pressed();

private:
    Ui::MnistLibtorchProjectClass ui;
};
