/********************************************************************************
** Form generated from reading UI file 'MnistLibtorchProject.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MNISTLIBTORCHPROJECT_H
#define UI_MNISTLIBTORCHPROJECT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MnistLibtorchProjectClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MnistLibtorchProjectClass)
    {
        if (MnistLibtorchProjectClass->objectName().isEmpty())
            MnistLibtorchProjectClass->setObjectName(QString::fromUtf8("MnistLibtorchProjectClass"));
        MnistLibtorchProjectClass->resize(600, 400);
        menuBar = new QMenuBar(MnistLibtorchProjectClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        MnistLibtorchProjectClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MnistLibtorchProjectClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MnistLibtorchProjectClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(MnistLibtorchProjectClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        MnistLibtorchProjectClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MnistLibtorchProjectClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MnistLibtorchProjectClass->setStatusBar(statusBar);

        retranslateUi(MnistLibtorchProjectClass);

        QMetaObject::connectSlotsByName(MnistLibtorchProjectClass);
    } // setupUi

    void retranslateUi(QMainWindow *MnistLibtorchProjectClass)
    {
        MnistLibtorchProjectClass->setWindowTitle(QCoreApplication::translate("MnistLibtorchProjectClass", "MnistLibtorchProject", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MnistLibtorchProjectClass: public Ui_MnistLibtorchProjectClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MNISTLIBTORCHPROJECT_H
