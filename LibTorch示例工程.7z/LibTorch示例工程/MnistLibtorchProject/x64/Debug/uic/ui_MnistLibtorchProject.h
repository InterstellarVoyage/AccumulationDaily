/********************************************************************************
** Form generated from reading UI file 'MnistLibtorchProject.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MNISTLIBTORCHPROJECT_H
#define UI_MNISTLIBTORCHPROJECT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MnistLibtorchProjectClass
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QGraphicsView *graphicsView;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPlainTextEdit *plainTextEdit;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MnistLibtorchProjectClass)
    {
        if (MnistLibtorchProjectClass->objectName().isEmpty())
            MnistLibtorchProjectClass->setObjectName(QString::fromUtf8("MnistLibtorchProjectClass"));
        MnistLibtorchProjectClass->resize(749, 638);
        centralWidget = new QWidget(MnistLibtorchProjectClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        graphicsView = new QGraphicsView(centralWidget);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));

        verticalLayout->addWidget(graphicsView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout_2->addWidget(pushButton);

        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout_2->addWidget(pushButton_2);


        horizontalLayout->addLayout(verticalLayout_2);

        plainTextEdit = new QPlainTextEdit(centralWidget);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        horizontalLayout->addWidget(plainTextEdit);


        verticalLayout->addLayout(horizontalLayout);

        verticalLayout->setStretch(0, 6);
        verticalLayout->setStretch(1, 1);

        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        MnistLibtorchProjectClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MnistLibtorchProjectClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 749, 26));
        MnistLibtorchProjectClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MnistLibtorchProjectClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MnistLibtorchProjectClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MnistLibtorchProjectClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MnistLibtorchProjectClass->setStatusBar(statusBar);

        retranslateUi(MnistLibtorchProjectClass);

        QMetaObject::connectSlotsByName(MnistLibtorchProjectClass);
    } // setupUi

    void retranslateUi(QMainWindow *MnistLibtorchProjectClass)
    {
        MnistLibtorchProjectClass->setWindowTitle(QCoreApplication::translate("MnistLibtorchProjectClass", "MnistLibtorchProject", nullptr));
        pushButton->setText(QCoreApplication::translate("MnistLibtorchProjectClass", "\351\200\211\346\213\251\345\233\276\345\203\217", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MnistLibtorchProjectClass", "\346\216\250\346\226\255\346\265\213\350\257\225", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MnistLibtorchProjectClass: public Ui_MnistLibtorchProjectClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MNISTLIBTORCHPROJECT_H
