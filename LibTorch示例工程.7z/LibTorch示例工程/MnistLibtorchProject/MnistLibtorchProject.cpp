#include "MnistLibtorchProject.h"
#include <QFileDialog>
#include <QGraphicsScene>
#include <QMessageBox>
#include <QDebug>
#undef slots
#include <torch/torch.h>
#include <ATen/ATen.h>
#include <torch/script.h>
#define slots Q_SLOTS

MnistLibtorchProject::MnistLibtorchProject(QWidget* parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	originalScene = new QGraphicsScene(this);
	ui.graphicsView->setScene(originalScene);
	connect(ui.pushButton, SIGNAL(pressed()), this, SLOT(InputImgPushButton_pressed()));
	connect(ui.pushButton_2, SIGNAL(pressed()), this, SLOT(InferImgNumber_pressed()));
}

void MnistLibtorchProject::InputImgPushButton_pressed()
{
	QString fileName = QFileDialog::getOpenFileName(this, tr("Open Input Image"), QDir::currentPath(),
		tr("Images") + " (*.jpg *.jpeg *.png *.bmp *.tiff *.tga *.webp)");
	std::string name = fileName.toLocal8Bit().toStdString();
	m_img = cv::imread(name);

	cv::Mat rgb;
	QImage tempImg;
	if (m_img.channels() == 3)
	{
		cv::cvtColor(m_img, rgb, cv::COLOR_BGR2RGB);
		tempImg = QImage((const unsigned char*)(rgb.data), rgb.cols, rgb.rows, rgb.cols * rgb.channels(), QImage::Format_RGB888);  //rgb.cols*rgb.channels()�����滻Ϊimage.step
	}
	else
	{
		//tempImg = QImage((const unsigned char*)(image.data), image.cols, image.rows, image.cols * image.channels(), QImage::Format_RGB888);
		tempImg = QImage((const unsigned char*)(m_img.data), m_img.cols, m_img.rows, m_img.cols * m_img.channels(), QImage::Format_Grayscale8);
	}

	QPixmap pixMap = QPixmap::fromImage(tempImg);
	originalScene->addPixmap(pixMap);
}

void MnistLibtorchProject::InferImgNumber_pressed()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	torch::jit::script::Module module;
	try {
		module = torch::jit::load("./model.pt");  //����ģ��
	}
	catch (const c10::Error& e) {
		QMessageBox::critical(this, tr("Error"), QString(tr("�޷�����model.ptģ��!")));
		return;
	}

	std::vector<int64_t> sizes = { 1, 1, m_img.rows, m_img.cols };  //����Ϊbatchsize��ͨ������ͼ��߶ȡ�ͼ�����
	at::TensorOptions options(at::ScalarType::Byte);
	at::Tensor tensor_image = torch::from_blob(m_img.data, at::IntList(sizes), options);//��opencv��ͼ������תΪTensor��������
	tensor_image = tensor_image.toType(at::kFloat);//תΪ��������������
	at::Tensor result = module.forward({ tensor_image }).toTensor();//����
	std::cout << "result:" << result<< endl;
	auto pred = result.argmax(1);
	std::cout << "max index:" << pred<< endl;
 
	auto max_result = result.max(1, true);
	auto max_index = std::get<1>(max_result).item<float>();
	ui.plainTextEdit->setPlainText(QString("�ƶϽ��: %0").arg(max_index));
}
